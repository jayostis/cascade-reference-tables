A synthetic RxNorm Prescribable release.
